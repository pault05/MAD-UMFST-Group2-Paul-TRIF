package com.example.dap_lab_7_8_broadcast_battery;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.tv.BroadcastInfoRequest;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    BroadcastReceiver broadcastReceiver_level = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int level= intent.getIntExtra("level", 0);
            ProgressBar pb = findViewById(R.id.pb);
            pb.setProgress(level);
            TextView textView = findViewById(R.id.battery);
            textView.setText(new StringBuilder().append("battery level: ").append(Integer.toString(level)).toString());

        }
    };


    BroadcastReceiver broadcastReceiver_low = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, "BATTERY LEVEL LOW!", duration);
            toast.show();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        registerReceiver(broadcastReceiver_level, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        registerReceiver(broadcastReceiver_low, new IntentFilter(Intent.ACTION_BATTERY_LOW));
    }
}