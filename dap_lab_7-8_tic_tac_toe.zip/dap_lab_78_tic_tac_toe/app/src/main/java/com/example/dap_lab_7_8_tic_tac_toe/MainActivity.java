package com.example.dap_lab_7_8_tic_tac_toe;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView r1c1, r1c2, r1c3, r2c1, r2c2, r2c3, r3c1, r3c2, r3c3;
    private TextView playerTurn;
    private boolean gameOver = false;
    private int currentPlayer = 0;

    String checkEmpty = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        r1c1 = findViewById(R.id.R1C1);
        r2c1 = findViewById(R.id.R2C1);
        r3c1 = findViewById(R.id.R3C1);

        r1c2 = findViewById(R.id.R1C2);
        r2c2 = findViewById(R.id.R2C2);
        r3c2 = findViewById(R.id.R3C2);

        r1c3 = findViewById(R.id.R1C3);
        r2c3 = findViewById(R.id.R2C3);
        r3c3 = findViewById(R.id.R3C3);

        playerTurn = findViewById(R.id.Player_turn);

        r1c1.setOnClickListener(this);
        r2c1.setOnClickListener(this);
        r3c1.setOnClickListener(this);
        r1c2.setOnClickListener(this);
        r2c2.setOnClickListener(this);
        r3c2.setOnClickListener(this);
        r1c3.setOnClickListener(this);
        r2c3.setOnClickListener(this);
        r3c3.setOnClickListener(this);

        Button resetGame = findViewById(R.id.reset_game_btn);
        resetGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameOver = false;

                r1c1.setText("");
                r1c2.setText("");
                r1c3.setText("");

                r2c1.setText("");
                r2c2.setText("");
                r2c3.setText("");

                r3c1.setText("");
                r3c2.setText("");
                r3c3.setText("");
            }
        });
    }


    @Override
    public void onClick(View v) {
        if (!gameOver) {
            switch (v.getId()) {

                    case 2131230729: //r1c1
                        if(checkEmpty.equals(r1c1.getText().toString())){
                                if(playerTurn.getText().toString().equals("Turn : O")){
                                        playerTurn.setText("Turn : X");
                                }
                                else
                                {
                                    playerTurn.setText("Turn : O");
                                }
                                if(currentPlayer ==0 && checkEmpty.equals(r1c1.getText().toString())){
                                    currentPlayer = 1;
                                    r1c1.setText("O");
                                }
                                else {
                                    currentPlayer = 0;
                                    r1c1.setText("X");
                                }
                                gameOver = checkWin();

                        }
                        break;
                    case 2131230732: //r2c1
                        if(checkEmpty.equals(r2c1.getText().toString())){
                            if(playerTurn.getText().toString().equals("Turn : O")){
                                playerTurn.setText("Turn : X");
                            }
                            else
                            {
                                playerTurn.setText("Turn : O");
                            }
                            if(currentPlayer ==0 && checkEmpty.equals(r2c1.getText().toString())){
                                currentPlayer = 1;
                                r2c1.setText("O");
                            }
                            else {
                                currentPlayer = 0;
                                r2c1.setText("X");
                            }
                            gameOver = checkWin();
                        }
                        break;
                    case 2131230735: //r3c1
                        if(checkEmpty.equals(r3c1.getText().toString())){
                            if(playerTurn.getText().toString().equals("Turn : O")){
                                playerTurn.setText("Turn : X");
                            }
                            else
                            {
                                playerTurn.setText("Turn : O");
                            }
                            if(currentPlayer ==0 && checkEmpty.equals(r3c1.getText().toString())){
                                currentPlayer = 1;
                                r3c1.setText("O");
                            }
                            else {
                                currentPlayer = 0;
                                r3c1.setText("X");
                            }
                            gameOver = checkWin();
                        }

                        break;
                    case 2131230730:  //r1c2
                        if(checkEmpty.equals(r1c2.getText().toString())){
                            if(playerTurn.getText().toString().equals("Turn : O")){
                                playerTurn.setText("Turn : X");
                            }
                            else
                            {
                                playerTurn.setText("Turn : O");
                            }
                            if(currentPlayer ==0 && checkEmpty.equals(r1c2.getText().toString())){
                                currentPlayer = 1;
                                r1c2.setText("O");
                            }
                            else {
                                currentPlayer = 0;
                                r1c2.setText("X");
                            }
                            gameOver = checkWin();
                        }

                        break;
                    case 2131230733: //r2c2
                        if(checkEmpty.equals(r2c2.getText().toString())){
                            if(playerTurn.getText().toString().equals("Turn : O")){
                                playerTurn.setText("Turn : X");
                            }
                            else
                            {
                                playerTurn.setText("Turn : O");
                            }
                            if(currentPlayer ==0 && checkEmpty.equals(r2c2.getText().toString())){
                                currentPlayer = 1;
                                r2c2.setText("O");
                            }
                            else {
                                currentPlayer = 0;
                                r2c2.setText("X");
                            }
                            gameOver = checkWin();
                        }
                        break;
                    case 2131230736: //r3c2
                        if(checkEmpty.equals(r3c2.getText().toString())){
                            if(playerTurn.getText().toString().equals("Turn : O")){
                                playerTurn.setText("Turn : X");
                            }
                            else
                            {
                                playerTurn.setText("Turn : O");
                            }
                            if(currentPlayer ==0 && checkEmpty.equals(r3c2.getText().toString())){
                                currentPlayer = 1;
                                r3c2.setText("O");
                            }
                            else {
                                currentPlayer = 0;
                                r3c2.setText("X");
                            }
                            gameOver = checkWin();
                        }
                        break;
                    case 2131230731: //r1c3
                        if(checkEmpty.equals(r1c3.getText().toString())){
                            if(playerTurn.getText().toString().equals("Turn : O")){
                                playerTurn.setText("Turn : X");
                            }
                            else
                            {
                                playerTurn.setText("Turn : O");
                            }
                            if(currentPlayer ==0 && checkEmpty.equals(r1c3.getText().toString())){
                                currentPlayer = 1;
                                r1c3.setText("O");
                            }
                            else {
                                currentPlayer = 0;
                                r1c3.setText("X");
                            }
                            gameOver = checkWin();
                        }
                        break;
                    case 2131230734: //r2c3
                        if(checkEmpty.equals(r2c3.getText().toString())){
                            if(playerTurn.getText().toString().equals("Turn : O")){
                                playerTurn.setText("Turn : X");
                            }
                            else
                            {
                                playerTurn.setText("Turn : O");
                            }
                            if(currentPlayer ==0 && checkEmpty.equals(r2c3.getText().toString())){
                                currentPlayer = 1;
                                r2c3.setText("O");
                            }
                            else {
                                currentPlayer = 0;
                                r2c3.setText("X");
                            }
                            gameOver = checkWin();
                        }
                        break;
                    case 2131230737:  //r3c3
                        if(checkEmpty.equals(r3c3.getText().toString())){
                            if(playerTurn.getText().toString().equals("Turn : O")){
                                playerTurn.setText("Turn : X");
                            }
                            else
                            {
                                playerTurn.setText("Turn : O");
                            }
                            if(currentPlayer ==0 && checkEmpty.equals(r3c3.getText().toString())){
                                currentPlayer = 1;
                                r3c3.setText("O");
                            }
                            else {
                                currentPlayer = 0;
                                r3c3.setText("X");
                            }
                            gameOver = checkWin();
                        }
                        break;
            }
        }
    }

    private boolean checkWin(){
        if(r1c1.getText().toString().equals(r1c2.getText().toString()) && r1c2.getText().toString().equals(r1c3.getText().toString()) && !r1c1.getText().toString().isEmpty())
        {
            if(r1c1.getText().toString().equals("X"))
            {
                Toast.makeText(this, "X WON", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "O WON", Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        else if(r2c1.getText().toString().equals(r2c2.getText().toString()) && r2c2.getText().toString().equals(r1c3.getText().toString()) && !r2c1.getText().toString().isEmpty())
        {
            if(r2c1.getText().toString().equals("X"))
            {
                Toast.makeText(this, "X WON", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "O WON", Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        else if(r3c1.getText().toString().equals(r3c2.getText().toString()) && r3c2.getText().toString().equals(r3c3.getText().toString()) && !r3c1.getText().toString().isEmpty())
        {
            if(r3c1.getText().toString().equals("X"))
            {
                Toast.makeText(this, "X WON", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "O WON", Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        if(r1c1.getText().toString().equals(r2c1.getText().toString()) && r2c1.getText().toString().equals(r3c1.getText().toString()) && !r1c1.getText().toString().isEmpty())
        {
            if(r1c1.getText().toString().equals("X"))
            {
                Toast.makeText(this, "X WON", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "O WON", Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        else if(r1c2.getText().toString().equals(r2c2.getText().toString()) && r2c2.getText().toString().equals(r3c2.getText().toString()) && !r1c2.getText().toString().isEmpty())
        {
            if(r1c2.getText().toString().equals("X"))
            {
                Toast.makeText(this, "X WON", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "O WON", Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        else if(r1c3.getText().toString().equals(r2c3.getText().toString()) && r2c3.getText().toString().equals(r3c3.getText().toString()) && !r1c3.getText().toString().isEmpty())
        {
            if(r1c3.getText().toString().equals("X"))
            {
                Toast.makeText(this, "X WON", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "O WON", Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        //diagonal


        if(r1c1.getText().toString().equals(r2c2.getText().toString()) && r2c2.getText().toString().equals(r3c3.getText().toString()) && !r1c1.getText().toString().isEmpty()) {
            if(r1c1.getText().toString().equals("X"))
            {
                Toast.makeText(this, "X WON", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "O WON", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        else if(r1c3.getText().toString().equals(r2c2.getText().toString()) && r2c2.getText().toString().equals(r2c1.getText().toString()) && !r1c1.getText().toString().isEmpty()) {
            if(r1c3.getText().toString().equals("X"))
            {
                Toast.makeText(this, "X WON", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "O WON", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return false;
    }

}