package com.example.dap_lab_9_10_network;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivityVolley extends AppCompatActivity {

    TextView volley_text;
    Button parse_btn;
    RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_volley);

        volley_text=findViewById(R.id.volley_text_view);
        parse_btn=findViewById(R.id.btn_parse);

        mQueue = Volley.newRequestQueue(this);

        parse_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                volley_text.setText("");
                jsonParse();
            }
        });
    }


    private void jsonParse()
    {
        //String url = "https://api.myjson.com/bins/kp9wz";
        String url = "https://reqres.in/api/users?page=2";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("data");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject employee = jsonArray.getJSONObject(i);

                        String firstName = employee.getString("first_name");
                        String ID = employee.getString("id");

                        String mail = employee.getString("email");

                        volley_text.append(firstName + "," + ID + "," + mail + "\n\n");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                volleyError.printStackTrace();
            }
        });

        mQueue.add(request);
    }

}