package com.example.dap_lab_9_10_network;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    TextView resultTextView;
    Button volley_btn;
    EditText server_editText;
    Button server_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultTextView = findViewById(R.id.text_view_result);
        volley_btn = findViewById(R.id.btn_volley);
        server_btn = findViewById(R.id.btn_server);
        server_editText = findViewById(R.id.edittext_server);


        OkHttpClient client = new OkHttpClient();

        String url = "https://reqres.in/api/users?page=2";

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if(response.isSuccessful()) {
                    final String myResponse = response.body().string();

                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            resultTextView.setText(myResponse);
                        }
                    });
                }
            }
        });


        volley_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivityVolley.class);
                startActivity(intent);
            }
        });


        server_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MessageSender.sendMessage(server_editText.getText().toString(), new MessageSender.MessageCallback() {
                    @Override
                    public void onMessageReceived(String message) {
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(MainActivity.this, message, duration);
                        toast.show();
                    }
                });

            }
        });

    }




}