package com.example.dap_lab4_fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnIntro = findViewById(R.id.buttonIntro);
        btnIntro.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentManager fragMan = getSupportFragmentManager();

                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, IntroFragment.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name")
                        .commit();
            }
        });

    Button btnCap1 = findViewById(R.id.buttonCap1);
    btnCap1.setOnClickListener(new OnClickListener() {
        @Override
        public void onClick(View v) {
            FragmentManager fragMan = getSupportFragmentManager();

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainerView, Cap1Fragment.class, null)
                    .setReorderingAllowed(true)
                    .addToBackStack("name")
                    .commit();

        }
    });

        Button btnCap2 = findViewById(R.id.buttonCap2);
        btnCap2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragMan = getSupportFragmentManager();

                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, Cap2.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name")
                        .commit();

            }
        });


        Button btnCap3 = findViewById(R.id.buttonCap3);
        btnCap3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragMan = getSupportFragmentManager();

                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, Cap3Fragment.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name")
                        .commit();

            }
        });

        Button btnCap4 = findViewById(R.id.buttonCap4);
        btnCap4.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragMan = getSupportFragmentManager();

                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, Cap4Fragment.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name")
                        .commit();

            }
        });

    }
}